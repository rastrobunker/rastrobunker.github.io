import { p as prisma } from './prisma.mjs';

async function upsertProductoMv(p) {
  const data = {
    idLegacy: p.idLegacy,
    codigo: p.codigo,
    categoria: p.categoria,
    marca: p.marca,
    modelo: p.modelo,
    anio: p.anio,
    lado: p.lado,
    condicion: p.condicion,
    precio: p.precio,
    vendido: p.vendido,
    cantidad: p.cantidad,
    posicion: p.posicion,
    alias: p.alias,
    tieneFoto: p.foto !== null
  };
  await prisma.productoMv.upsert({
    where: { id: p.id },
    create: { id: p.id, ...data },
    update: data
  });
}
async function deleteProductoMv(id) {
  await prisma.productoMv.deleteMany({ where: { id } });
}

export { deleteProductoMv as d, upsertProductoMv as u };
//# sourceMappingURL=productoMv.mjs.map
