import { i as getHeader, e as createError } from './nitro.mjs';

function requireAdmin(event) {
  const codigo = getHeader(event, "x-admin-code");
  if (!codigo || codigo !== process.env.ADMIN_CODE) {
    throw createError({ statusCode: 401, statusMessage: "Codigo de administrador invalido" });
  }
}

export { requireAdmin as r };
//# sourceMappingURL=requireAdmin.mjs.map
