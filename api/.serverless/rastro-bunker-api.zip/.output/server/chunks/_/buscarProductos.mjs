import { p as prisma } from './prisma.mjs';

async function buscarProductos(query) {
  const page = Math.max(1, Number(query.page) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(query.pageSize) || 30));
  const where = {};
  if (query.categoria) where.categoria = String(query.categoria);
  if (query.marca) where.marca = String(query.marca);
  if (query.modelo) where.modelo = String(query.modelo);
  if (query.anio) where.anio = String(query.anio);
  if (query.lado) where.lado = String(query.lado);
  if (query.codigo) where.codigo = { contains: String(query.codigo) };
  if (query.vendido !== void 0) where.vendido = query.vendido === "true" || query.vendido === "1" || query.vendido === true;
  if (query.q) {
    const texto = String(query.q);
    where.OR = [
      { codigo: { contains: texto } },
      { alias: { contains: texto } },
      { marca: { contains: texto } },
      { modelo: { contains: texto } },
      { categoria: { contains: texto } }
    ];
  }
  const [total, items] = await Promise.all([
    prisma.productoMv.count({ where }),
    prisma.productoMv.findMany({
      where,
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: { updatedAt: "desc" }
    })
  ]);
  return {
    data: items,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize))
    }
  };
}

export { buscarProductos as b };
//# sourceMappingURL=buscarProductos.mjs.map
