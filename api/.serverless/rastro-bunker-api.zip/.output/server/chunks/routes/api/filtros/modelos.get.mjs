import { d as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const modelos_get = defineEventHandler(async (event) => {
  const q = getQuery(event);
  const where = { modelo: { not: null }, vendido: false };
  if (q.marca) where.marca = String(q.marca);
  const rows = await prisma.productoMv.findMany({
    where,
    distinct: ["modelo"],
    select: { modelo: true },
    orderBy: { modelo: "asc" }
  });
  return rows.map((r) => r.modelo).filter(Boolean);
});

export { modelos_get as default };
//# sourceMappingURL=modelos.get.mjs.map
