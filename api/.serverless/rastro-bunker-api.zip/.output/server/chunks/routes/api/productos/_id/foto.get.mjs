import { d as defineEventHandler, f as getRouterParam, e as createError, h as setResponseHeader } from '../../../../_/nitro.mjs';
import { p as prisma } from '../../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const foto_get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "id requerido" });
  const producto = await prisma.producto.findUnique({ where: { id }, select: { foto: true } });
  if (!(producto == null ? void 0 : producto.foto)) throw createError({ statusCode: 404, statusMessage: "Sin foto" });
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(producto.foto);
  if (!match) throw createError({ statusCode: 500, statusMessage: "Formato de foto invalido" });
  setResponseHeader(event, "Content-Type", match[1]);
  setResponseHeader(event, "Cache-Control", "public, max-age=86400");
  return Buffer.from(match[2], "base64");
});

export { foto_get as default };
//# sourceMappingURL=foto.get.mjs.map
