import { d as defineEventHandler, f as getRouterParam, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { p as prisma } from '../../../../_/prisma.mjs';
import { u as upsertProductoMv } from '../../../../_/productoMv.mjs';
import { r as requireAdmin } from '../../../../_/requireAdmin.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const vender_post = defineEventHandler(async (event) => {
  var _a;
  requireAdmin(event);
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "id requerido" });
  const body = await readBody(event).catch(() => ({}));
  const cantidadVendida = Math.max(1, Number(body == null ? void 0 : body.cantidad) || 1);
  const producto = await prisma.producto.findUnique({ where: { id } });
  if (!producto) throw createError({ statusCode: 404, statusMessage: "Producto no encontrado" });
  if (producto.vendido) throw createError({ statusCode: 409, statusMessage: "El producto ya esta vendido" });
  const disponible = (_a = producto.cantidad) != null ? _a : 1;
  if (cantidadVendida > disponible) {
    throw createError({ statusCode: 400, statusMessage: `Solo hay ${disponible} unidad(es) disponible(s)` });
  }
  const nuevaCantidad = disponible - cantidadVendida;
  const actualizado = await prisma.producto.update({
    where: { id },
    data: {
      cantidad: nuevaCantidad,
      vendido: nuevaCantidad <= 0
    }
  });
  await upsertProductoMv(actualizado);
  return actualizado;
});

export { vender_post as default };
//# sourceMappingURL=vender.post.mjs.map
