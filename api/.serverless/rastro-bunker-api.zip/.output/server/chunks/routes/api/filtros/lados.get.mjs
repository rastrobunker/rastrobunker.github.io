import { d as defineEventHandler } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const lados_get = defineEventHandler(async () => {
  const rows = await prisma.productoMv.findMany({
    where: { lado: { not: null }, vendido: false },
    distinct: ["lado"],
    select: { lado: true },
    orderBy: { lado: "asc" }
  });
  return rows.map((r) => r.lado).filter(Boolean);
});

export { lados_get as default };
//# sourceMappingURL=lados.get.mjs.map
