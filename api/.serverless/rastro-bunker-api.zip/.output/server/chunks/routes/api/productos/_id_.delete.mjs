import { d as defineEventHandler, f as getRouterParam, e as createError, s as setResponseStatus } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import { d as deleteProductoMv } from '../../../_/productoMv.mjs';
import { r as requireAdmin } from '../../../_/requireAdmin.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const _id__delete = defineEventHandler(async (event) => {
  requireAdmin(event);
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "id requerido" });
  const existente = await prisma.producto.findUnique({ where: { id } });
  if (!existente) throw createError({ statusCode: 404, statusMessage: "Producto no encontrado" });
  await prisma.producto.delete({ where: { id } });
  await deleteProductoMv(id);
  setResponseStatus(event, 204);
  return null;
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
