import { d as defineEventHandler, f as getRouterParam, e as createError } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "id requerido" });
  const producto = await prisma.producto.findUnique({ where: { id } });
  if (!producto) throw createError({ statusCode: 404, statusMessage: "Producto no encontrado" });
  return producto;
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
