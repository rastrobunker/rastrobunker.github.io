import { d as defineEventHandler, f as getRouterParam, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import { u as upsertProductoMv } from '../../../_/productoMv.mjs';
import { r as requireAdmin } from '../../../_/requireAdmin.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
  requireAdmin(event);
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "id requerido" });
  const existente = await prisma.producto.findUnique({ where: { id } });
  if (!existente) throw createError({ statusCode: 404, statusMessage: "Producto no encontrado" });
  const body = await readBody(event);
  const producto = await prisma.producto.update({
    where: { id },
    data: {
      codigo: (_a = body.codigo) != null ? _a : existente.codigo,
      categoria: (_b = body.categoria) != null ? _b : existente.categoria,
      marca: (_c = body.marca) != null ? _c : existente.marca,
      modelo: (_d = body.modelo) != null ? _d : existente.modelo,
      anio: (_e = body.anio) != null ? _e : existente.anio,
      lado: (_f = body.lado) != null ? _f : existente.lado,
      condicion: (_g = body.condicion) != null ? _g : existente.condicion,
      precio: (_h = body.precio) != null ? _h : existente.precio,
      vendido: (_i = body.vendido) != null ? _i : existente.vendido,
      cantidad: (_j = body.cantidad) != null ? _j : existente.cantidad,
      detalle: (_k = body.detalle) != null ? _k : existente.detalle,
      posicion: (_l = body.posicion) != null ? _l : existente.posicion,
      bgc: (_m = body.bgc) != null ? _m : existente.bgc,
      fit: (_n = body.fit) != null ? _n : existente.fit,
      alias: (_o = body.alias) != null ? _o : existente.alias,
      foto: (_p = body.foto) != null ? _p : existente.foto
    }
  });
  await upsertProductoMv(producto);
  return producto;
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
