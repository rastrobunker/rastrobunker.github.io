import { d as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const verificar_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => ({}));
  const codigo = String((body == null ? void 0 : body.codigo) || "");
  if (!codigo || codigo !== process.env.ADMIN_CODE) {
    throw createError({ statusCode: 401, statusMessage: "Codigo incorrecto" });
  }
  return { ok: true };
});

export { verificar_post as default };
//# sourceMappingURL=verificar.post.mjs.map
