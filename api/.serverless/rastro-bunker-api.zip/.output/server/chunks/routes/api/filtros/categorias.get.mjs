import { d as defineEventHandler } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const categorias_get = defineEventHandler(async () => {
  const rows = await prisma.productoMv.findMany({
    where: { categoria: { not: null }, vendido: false },
    distinct: ["categoria"],
    select: { categoria: true },
    orderBy: { categoria: "asc" }
  });
  return rows.map((r) => r.categoria).filter(Boolean);
});

export { categorias_get as default };
//# sourceMappingURL=categorias.get.mjs.map
