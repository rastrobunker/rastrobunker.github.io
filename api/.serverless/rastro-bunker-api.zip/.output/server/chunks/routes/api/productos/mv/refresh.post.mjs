import { d as defineEventHandler } from '../../../../_/nitro.mjs';
import { p as prisma } from '../../../../_/prisma.mjs';
import { r as requireAdmin } from '../../../../_/requireAdmin.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const refresh_post = defineEventHandler(async (event) => {
  requireAdmin(event);
  await prisma.$executeRawUnsafe("CALL sp_refresh_productos_mv()");
  const total = await prisma.productoMv.count();
  return { ok: true, total };
});

export { refresh_post as default };
//# sourceMappingURL=refresh.post.mjs.map
