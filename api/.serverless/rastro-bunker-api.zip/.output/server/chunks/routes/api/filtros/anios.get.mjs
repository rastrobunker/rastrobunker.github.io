import { d as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const anios_get = defineEventHandler(async (event) => {
  const q = getQuery(event);
  const where = { anio: { not: null }, vendido: false };
  if (q.marca) where.marca = String(q.marca);
  if (q.modelo) where.modelo = String(q.modelo);
  const rows = await prisma.productoMv.findMany({
    where,
    distinct: ["anio"],
    select: { anio: true },
    orderBy: { anio: "asc" }
  });
  return rows.map((r) => r.anio).filter(Boolean);
});

export { anios_get as default };
//# sourceMappingURL=anios.get.mjs.map
