import { d as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { b as buscarProductos } from '../../../_/buscarProductos.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '../../../_/prisma.mjs';
import '@prisma/client';

const buscar_get = defineEventHandler(async (event) => {
  const q = getQuery(event);
  return buscarProductos(q);
});

export { buscar_get as default };
//# sourceMappingURL=buscar.get.mjs.map
