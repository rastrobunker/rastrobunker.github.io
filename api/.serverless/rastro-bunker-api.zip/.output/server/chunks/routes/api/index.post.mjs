import { d as defineEventHandler, r as readBody, e as createError, s as setResponseStatus } from '../../_/nitro.mjs';
import { p as prisma } from '../../_/prisma.mjs';
import { u as upsertProductoMv } from '../../_/productoMv.mjs';
import { r as requireAdmin } from '../../_/requireAdmin.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const index_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
  requireAdmin(event);
  const body = await readBody(event);
  if (!body || typeof body !== "object") {
    throw createError({ statusCode: 400, statusMessage: "Body invalido" });
  }
  const producto = await prisma.producto.create({
    data: {
      idLegacy: (_a = body.idLegacy) != null ? _a : null,
      codigo: (_b = body.codigo) != null ? _b : null,
      categoria: (_c = body.categoria) != null ? _c : null,
      marca: (_d = body.marca) != null ? _d : null,
      modelo: (_e = body.modelo) != null ? _e : null,
      anio: (_f = body.anio) != null ? _f : null,
      lado: (_g = body.lado) != null ? _g : null,
      condicion: (_h = body.condicion) != null ? _h : null,
      precio: (_i = body.precio) != null ? _i : null,
      vendido: Boolean(body.vendido),
      cantidad: (_j = body.cantidad) != null ? _j : null,
      detalle: (_k = body.detalle) != null ? _k : null,
      posicion: (_l = body.posicion) != null ? _l : null,
      bgc: (_m = body.bgc) != null ? _m : null,
      fit: (_n = body.fit) != null ? _n : null,
      alias: (_o = body.alias) != null ? _o : null,
      foto: (_p = body.foto) != null ? _p : null
    }
  });
  await upsertProductoMv(producto);
  setResponseStatus(event, 201);
  return producto;
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
