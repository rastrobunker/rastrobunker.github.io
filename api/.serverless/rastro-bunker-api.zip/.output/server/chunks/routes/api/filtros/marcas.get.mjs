import { d as defineEventHandler } from '../../../_/nitro.mjs';
import { p as prisma } from '../../../_/prisma.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';

const marcas_get = defineEventHandler(async () => {
  const rows = await prisma.productoMv.findMany({
    where: { marca: { not: null }, vendido: false },
    distinct: ["marca"],
    select: { marca: true },
    orderBy: { marca: "asc" }
  });
  return rows.map((r) => r.marca).filter(Boolean);
});

export { marcas_get as default };
//# sourceMappingURL=marcas.get.mjs.map
